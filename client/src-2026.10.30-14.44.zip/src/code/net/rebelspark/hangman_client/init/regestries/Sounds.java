package code.net.rebelspark.hangman_client.init.regestries;

import javax.sound.midi.SoundbankResource;

public class Sounds {

    //public static SoundbankResource ARIA_MATH =

}
