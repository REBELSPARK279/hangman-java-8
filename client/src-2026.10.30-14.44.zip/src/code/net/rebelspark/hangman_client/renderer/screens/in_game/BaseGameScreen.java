package code.net.rebelspark.hangman_client.renderer.screens.in_game;

import code.net.rebelspark.hangman_client.renderer.util.Button;

import java.awt.*;

public class BaseGameScreen {

    private static final Button A = new Button();

    public static void render(Graphics g, int w, int h) {

    }
}
