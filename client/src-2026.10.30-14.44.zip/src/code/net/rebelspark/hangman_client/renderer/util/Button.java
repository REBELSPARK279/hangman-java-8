package code.net.rebelspark.hangman_client.renderer.util;

import code.net.rebelspark.hangman_client.eventHandlers.MouseMovementHandler;
import code.net.rebelspark.hangman_client.init.regestries.Fonts;
import code.net.rebelspark.hangman_client.state.GameStates;
import code.net.rebelspark.hangman_client.util.Logger;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Objects;

public class Button {

    protected static class Hitbox {
        private int hitboxX;
        private int hitboxY;
        private int hitboxW;
        private int hitboxH;

        protected Hitbox(){}

        protected void setHitbox(int x, int y, int w, int h) {
            hitboxX = x;
            hitboxY = y;
            hitboxW = w;
            hitboxH = h;
        }

        @Deprecated
        protected boolean checkBounds(MouseEvent e) {
            int mouseX = e.getX();
            int mouseY = e.getY();
            return((mouseX >= hitboxX) && (mouseX <= hitboxX + hitboxW) && (mouseY >= hitboxY) && (mouseY <= hitboxY + hitboxH));
        }

        protected boolean checkBounds() {
            int mouseX = MouseMovementHandler.getMouseX();
            int mouseY = MouseMovementHandler.getMouseY();
            return((mouseX >= hitboxX) && (mouseX <= hitboxX + hitboxW) && (mouseY >= hitboxY) && (mouseY <= hitboxY + hitboxH));
        }

        public String toString() {
            return ("hitbox [x " + hitboxX + ", y " + hitboxY + ", w " + hitboxW + ", h " + hitboxH + "]");
        }

    }

    protected static class Border {

        private Rect borderIdle;
        private Rect borderHover;

        protected Border(final float x, final float y, final float w, final float h, final float t, Color idleColor, Color hoverColor) {
            borderIdle = new Rect(x - (w / 2), y - (h / 2), w, h, t, idleColor);
            borderHover = new Rect(x - (w / 2), y - (h / 2), w, h, t, hoverColor);
        }

        protected void render(Graphics g, boolean hovering) {
            Rect renderThis = hovering? borderHover: borderIdle;
            renderThis.render(g);
        }
    }

    private enum Type {
        NONE,
        TEXT,
        TEXT_NON_HOVER,
        COLOR,
        COLOR_NON_HOVER,
        COLOR_TEXT,
        COLOR_TEXT_NON_HOVER,
        COLOR_NON_HOVER_TEXT,
        COLOR_NON_HOVER_TEXT_NON_HOVER,
        IMAGE,
        IMAGE_NON_HOVER
    }

    public static HashSet<Button> buttons = new HashSet<>();
    private static final float DEFAULT_TEXT_SIZE = ((float)(65.0 / 1080.0));

    private float x;
    private float y;
    private float width;
    private float height;
    private String text;
    private float textSize;
    private BufferedImage idleImage;
    private BufferedImage hoverImage;
    private Color idleColor;
    private Color hoverColor;
    private Color idleTextColor;
    private Color hoverTextColor;
    private Type type;
    private Hitbox hitbox;
    private Runnable runnable;
    private GameStates screen;
    private Border border;


    @Deprecated
    public Button() {
        this.x = 0;
        this.y = 0;
        this.width = 10;
        this.height = 10;
        buttons.add(this);
        hitbox = new Hitbox();
    }

    @Deprecated
    public Button(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.type = Type.NONE;
        buttons.add(this);
        hitbox = new Hitbox();
    }

    @Deprecated
    public Button(int x, int y, int width, int height, String text) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.text = text;
        this.textSize = (float)(65.0 / 1080.0);
        this.type = Type.TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
    }

    @Deprecated
    public Button(int x, int y, int width, int height, String text, int textSize) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.type = Type.TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
    }

    //-------------------------------------------------------------------------------------------------------
    //                                            TEXT BASED
    //-------------------------------------------------------------------------------------------------------

    //creates plain text button centered at [x, y] with font size 65 and static color black
    public Button(GameStates screen, float x, float y, String text, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.text = text;
        this.textSize = (float)(65.0 / 1080.0);
        this.idleTextColor = Color.black;
        this.type = Type.TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    //creates plain text button centered at [x, y] with font size 65 and static color 'idleTextColor'
    public Button(GameStates screen, float x, float y, String text, Color idleTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.text = text;
        this.textSize = (float)(65.0 / 1080.0);
        this.idleTextColor = idleTextColor;
        this.type = Type.TEXT_NON_HOVER;
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
        buttons.add(this);
    }

    //creates plain text button centered at [x, y] with font size 65 and hoverable color 'idleTextColor' <--> 'hoverTextColor'
    public Button(GameStates screen, float x, float y, String text, Color idleTextColor, Color hoverTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.text = text;
        this.textSize = (float)(65.0 / 1080.0);
        this.idleTextColor = idleTextColor;
        this.hoverTextColor = hoverTextColor;
        this.type = Type.TEXT;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    //creates plain text button centered at ['x', 'y'] with font size 'textSize' and static color 'idleTextColor'
    public Button(GameStates screen, float x, float y, String text, int textSize, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.idleTextColor = Color.black;
        this.type = Type.TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    //creates plain text button centered at ['x', 'y'] with font size 'textSize' and static color 'idleTextColor'
    public Button(GameStates screen, float x, float y, String text, int textSize, Color idleTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.idleTextColor = idleTextColor;
        this.type = Type.TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    //creates plain text button centered at ['x', 'y'] with font size 'textSize' and hoverable color 'idleTextColor' <--> 'hoverTextColor'
    public Button(GameStates screen, float x, float y, String text, int textSize, Color idleTextColor, Color hoverTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.idleTextColor = idleTextColor;
        this.hoverTextColor = hoverTextColor;
        this.type = Type.TEXT;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    //-------------------------------------------------------------------------------------------------------
    //                                             IMAGE BASED
    //-------------------------------------------------------------------------------------------------------

    public Button(GameStates screen, float x, float y, float width, float height, BufferedImage idleImage, BufferedImage hoverImage, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleImage = idleImage;
        this.hoverImage = hoverImage;
        this.type = Type.IMAGE;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, BufferedImage idleImage, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleImage = idleImage;
        this.type = Type.IMAGE_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    //-------------------------------------------------------------------------------------------------------
    //                                            COLOR BASED         [pain]
    //-------------------------------------------------------------------------------------------------------

    ///just color

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.type = Type.COLOR_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, Color hoverColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.hoverColor = hoverColor;
        this.type = Type.COLOR;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    ///


    /// static text color hoverable bg color
    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, Color hoverColor, String text, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.hoverColor = hoverColor;
        this.text = text;
        this.textSize = DEFAULT_TEXT_SIZE;
        this.idleTextColor = Color.BLACK;
        this.type = Type.COLOR_TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, Color hoverColor, String text, Color idleTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.hoverColor = hoverColor;
        this.text = text;
        this.textSize = DEFAULT_TEXT_SIZE;
        this.idleTextColor = idleTextColor;
        this.type = Type.COLOR_TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, Color hoverColor, String text, float textSize, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.hoverColor = hoverColor;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.idleTextColor = Color.BLACK;
        this.type = Type.COLOR_TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, Color hoverColor, String text, float textSize, Color idleTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.hoverColor = hoverColor;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.idleTextColor = idleTextColor;
        this.type = Type.COLOR_TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

///


///static bg color static text color

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, String text, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.text = text;
        this.textSize = DEFAULT_TEXT_SIZE;
        this.idleTextColor = Color.BLACK;
        this.type = Type.COLOR_NON_HOVER_TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, String text, Color idleTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.text = text;
        this.textSize = DEFAULT_TEXT_SIZE;
        this.idleTextColor = idleTextColor;
        this.type = Type.COLOR_NON_HOVER_TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, String text, float textSize, Color idleTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.idleTextColor = idleTextColor;
        this.type = Type.COLOR_NON_HOVER_TEXT_NON_HOVER;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    ///


    ///static bg color hoverable text color

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, String text, Color idleTextColor, Color hoverTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.text = text;
        this.textSize = DEFAULT_TEXT_SIZE;
        this.idleTextColor = idleTextColor;
        this.hoverTextColor = hoverTextColor;
        this.type = Type.COLOR_NON_HOVER_TEXT;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, String text, float textSize, Color idleTextColor, Color hoverTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.idleTextColor = idleTextColor;
        this.hoverTextColor = hoverTextColor;
        this.type = Type.COLOR_NON_HOVER_TEXT;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    ///


    ///hoverable text hoverable bg

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, Color hoverColor, String text, Color idleTextColor, Color hoverTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.hoverColor = hoverColor;
        this.text = text;
        this.textSize = DEFAULT_TEXT_SIZE;
        this.idleTextColor = idleTextColor;
        this.hoverTextColor = hoverTextColor;
        this.type = Type.COLOR_TEXT;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    public Button(GameStates screen, float x, float y, float width, float height, Color idleColor, Color hoverColor, String text, float textSize, Color idleTextColor, Color hoverTextColor, Runnable runnable) {
        this.screen = screen;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.idleColor = idleColor;
        this.hoverColor = hoverColor;
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
        this.idleTextColor = idleTextColor;
        this.hoverTextColor = hoverTextColor;
        this.type = Type.COLOR_TEXT;
        buttons.add(this);
        hitbox = new Hitbox();
        this.runnable = Objects.requireNonNull(runnable);
    }

    ///

    public Button appendBorder(int thickness, Color idleColor, Color hoverColor) {
        border = new Border(x, y, width, height, thickness, idleColor, hoverColor);
        return (this);
    }

    public void mouseClicked(MouseEvent e) {
        if (hitbox.checkBounds(e)) {
            Logger.DEBUG(this + " clicked");
            if (runnable == null) {
                Logger.FATAL(this + " is missing action!");
                System.exit(2);
            } else {
                runnable.run();
            }
        }
    }

    public void setPos(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void setPos(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setText(String text) {
        this.setText(text, 65);
    }

    public void setText(String text, int textSize) {
        this.text = text;
        this.textSize = (float)(textSize / 1080.0);
    }

    public GameStates getRenderScreen() {
        return (this.screen);
    }

    public void render(Graphics g, final int WINDOW_WIDTH, final int WINDOW_HEIGHT) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        FontMetrics fontMetrics;
        int W;
        int H;
        int X;
        int Y;
        switch (type) {
            case NONE:
                break;
            case TEXT:
                g2d.setFont(Fonts.RUBIK.deriveFont(textSize * WINDOW_HEIGHT));
                fontMetrics = g2d.getFontMetrics();
                X = (int)((x * WINDOW_WIDTH) - (fontMetrics.stringWidth(text) / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - ((fontMetrics.getDescent() + fontMetrics.getAscent()) / 2.0));
                g2d.setColor(hitbox.checkBounds()? hoverTextColor: idleTextColor);
                g2d.drawString(text, X, Y + fontMetrics.getAscent());
                hitbox.setHitbox(X, Y, fontMetrics.stringWidth(text), (fontMetrics.getAscent() + fontMetrics.getDescent()));
                g2d.setColor(Color.BLACK);
                break;
            case TEXT_NON_HOVER:
                g2d.setFont(Fonts.RUBIK.deriveFont(textSize * WINDOW_HEIGHT));
                fontMetrics = g2d.getFontMetrics();
                X = (int)((x * WINDOW_WIDTH) - (fontMetrics.stringWidth(text) / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - ((fontMetrics.getDescent() + fontMetrics.getAscent()) / 2.0));
                g2d.setColor(idleTextColor);
                g2d.drawString(text, X, Y + fontMetrics.getAscent());
                hitbox.setHitbox(X, Y, fontMetrics.stringWidth(text), (fontMetrics.getAscent() + fontMetrics.getDescent()));
                g2d.setColor(Color.BLACK);
                break;
            case IMAGE:
                W = (int)(width * WINDOW_WIDTH);
                H = (int)(height * WINDOW_HEIGHT);
                X = (int)((x * WINDOW_WIDTH) - (W / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - (H / 2.0));
                hitbox.setHitbox(X, Y, W, H);
                BufferedImage image = hitbox.checkBounds()? hoverImage: idleImage;
                g.drawImage(image, X, Y, W, H, null);
                break;
            case IMAGE_NON_HOVER:
                W = (int)(width * WINDOW_WIDTH);
                H = (int)(height * WINDOW_HEIGHT);
                X = (int)((x * WINDOW_WIDTH) - (W / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - (H / 2.0));
                hitbox.setHitbox(X, Y, W, H);
                BufferedImage imageNonHover = idleImage;
                g.drawImage(imageNonHover, X, Y, W, H, null);
                break;
            case COLOR:
                W = (int)(width * WINDOW_WIDTH);
                H = (int)(height * WINDOW_HEIGHT);
                X = (int)((x * WINDOW_WIDTH) - (W / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - (H / 2.0));
                hitbox.setHitbox(X, Y, W, H);
                g.setColor(hitbox.checkBounds()? hoverColor: idleColor);
                g.fillRect(X, Y, W, H);
                g.setColor(Color.BLACK);
                break;
            case COLOR_NON_HOVER:
                W = (int)(width * WINDOW_WIDTH);
                H = (int)(height * WINDOW_HEIGHT);
                X = (int)((x * WINDOW_WIDTH) - (W / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - (H / 2.0));
                hitbox.setHitbox(X, Y, W, H);
                g.setColor(idleColor);
                g.fillRect(X, Y, W, H);
                g.setColor(Color.BLACK);
                break;
            case COLOR_TEXT:
                g2d.setFont(Fonts.RUBIK.deriveFont(textSize * WINDOW_HEIGHT));
                fontMetrics = g2d.getFontMetrics();
                W = (int)(width * WINDOW_WIDTH);
                H = (int)(height * WINDOW_HEIGHT);
                X = (int)((x * WINDOW_WIDTH) - (W / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - (H / 2.0));
                hitbox.setHitbox(X, Y, W, H);
                g.setColor(hitbox.checkBounds()? hoverColor: idleColor);
                g.fillRect(X, Y, W, H);
                g2d.setColor(hitbox.checkBounds()? hoverTextColor: idleTextColor);
                g2d.drawString(text, X + (int)((W - fontMetrics.stringWidth(text)) / 2.0), (int)((Y + fontMetrics.getAscent())
                        + ((H - (fontMetrics.getDescent()) - fontMetrics.getAscent()) / 2.0)));
                g.setColor(Color.BLACK);
                g2d.setColor(Color.BLACK);
                break;
            case COLOR_TEXT_NON_HOVER:
                g2d.setFont(Fonts.RUBIK.deriveFont(textSize * WINDOW_HEIGHT));
                fontMetrics = g2d.getFontMetrics();
                W = (int)(width * WINDOW_WIDTH);
                H = (int)(height * WINDOW_HEIGHT);
                X = (int)((x * WINDOW_WIDTH) - (W / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - (H / 2.0));
                hitbox.setHitbox(X, Y, W, H);
                g.setColor(hitbox.checkBounds()? hoverColor: idleColor);
                g.fillRect(X, Y, W, H);
                g2d.setColor(idleTextColor);
                g2d.drawString(text, X + (int)((W - fontMetrics.stringWidth(text)) / 2.0), (int)((Y + fontMetrics.getAscent())
                        + ((H - (fontMetrics.getDescent()) - fontMetrics.getAscent()) / 2.0)));
                g.setColor(Color.BLACK);
                g2d.setColor(Color.BLACK);
                break;
            case COLOR_NON_HOVER_TEXT:
                g2d.setFont(Fonts.RUBIK.deriveFont(textSize * WINDOW_HEIGHT));
                fontMetrics = g2d.getFontMetrics();
                W = (int)(width * WINDOW_WIDTH);
                H = (int)(height * WINDOW_HEIGHT);
                X = (int)((x * WINDOW_WIDTH) - (W / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - (H / 2.0));
                hitbox.setHitbox(X, Y, W, H);
                g.setColor(idleColor);
                g.fillRect(X, Y, W, H);
                g2d.setColor(hitbox.checkBounds()? hoverTextColor: idleTextColor);
                g2d.drawString(text, X + (int)((W - fontMetrics.stringWidth(text)) / 2.0), (int)((Y + fontMetrics.getAscent())
                        + ((H - (fontMetrics.getDescent()) - fontMetrics.getAscent()) / 2.0)));
                g.setColor(Color.BLACK);
                g2d.setColor(Color.BLACK);
                break;
            case COLOR_NON_HOVER_TEXT_NON_HOVER:
                g2d.setFont(Fonts.RUBIK.deriveFont(textSize * WINDOW_HEIGHT));
                fontMetrics = g2d.getFontMetrics();
                W = (int)(width * WINDOW_WIDTH);
                H = (int)(height * WINDOW_HEIGHT);
                X = (int)((x * WINDOW_WIDTH) - (W / 2.0));
                Y = (int)((y * WINDOW_HEIGHT) - (H / 2.0));
                hitbox.setHitbox(X, Y, W, H);
                g.setColor(idleColor);
                g.fillRect(X, Y, W, H);
                g2d.setColor(idleTextColor);
                g2d.drawString(text, X + (int)((W - fontMetrics.stringWidth(text)) / 2.0), (int)((Y + fontMetrics.getAscent())
                        + ((H - (fontMetrics.getDescent()) - fontMetrics.getAscent()) / 2.0)));
                g.setColor(Color.BLACK);
                g2d.setColor(Color.BLACK);
                break;
        }
        if (border != null) {
            border.render(g, hitbox.checkBounds());
        }
    }

    public String toString() {
        return ("Button {x " + x + ", y " + y + ", w " + width + ", h " + height + ", text " + text + ", text_size " + textSize
            + ", idle_text_color " + idleTextColor + ", hover_text_color " + hoverTextColor + ", idle_color " + idleColor
            + ", hover_color " + hoverColor + ", idle_image " + idleImage + ", hover_image " + hoverColor + ", type " + type
            + ", hitbox " + hitbox + ", action " + runnable + "}");
    }

}
