package code.net.rebelspark.hangman_client;

import code.net.rebelspark.hangman_client.init.InitHandler;
import code.net.rebelspark.hangman_client.util.Logger;

public class Main {
    public static void main(String[] args) {
        Logger.FATAL(0.1 + 0.2);
        InitHandler.init();
    }
}
