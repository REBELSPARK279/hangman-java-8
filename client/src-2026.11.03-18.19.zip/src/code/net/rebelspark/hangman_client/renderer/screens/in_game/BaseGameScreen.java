package code.net.rebelspark.hangman_client.renderer.screens.in_game;

import code.net.rebelspark.hangman_client.renderer.GamePanel;
import code.net.rebelspark.hangman_client.renderer.util.Button;
import code.net.rebelspark.hangman_client.renderer.util.Keyboard;
import code.net.rebelspark.hangman_client.state.GameStates;
import code.net.rebelspark.hangman_client.util.Logger;

import java.awt.*;
import java.util.function.Consumer;

public class BaseGameScreen {

    private static void doNon() {}

    private static Keyboard keyboard = new Keyboard(GameStates.IN_GAME_BASE, 0f, 0.5f, (character) -> {
        Logger.INFO("Keyboard key clicked");
        Logger.DEBUG(character);
    });

    public static void render(Graphics g, int w, int h) {
        keyboard.render(g, w, h);
    }
}
